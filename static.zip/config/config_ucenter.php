<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'shbbs');
define('UC_DBPW', '080314shbbs');
define('UC_DBNAME', 'shbbs');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`shbbs`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'Z1MeJ0I0k4Ibf8ecB0H2dfY5jaxdN9s4j972e6x8IcEayeCcGfLap6y5qde4ScHd');
define('UC_API', 'http://149.129.76.153/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);